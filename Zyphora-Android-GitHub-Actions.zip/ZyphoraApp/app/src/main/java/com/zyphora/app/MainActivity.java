package com.zyphora.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView label(String text, float size, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(16), dp(12), dp(16), dp(12));
        return t;
    }

    private View card(String title, String subtitle) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4), dp(4), dp(4), dp(4));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(13,26,14));
        bg.setCornerRadius(dp(18));
        box.setBackground(bg);
        TextView h = label(title, 20, Color.rgb(243,255,243));
        h.setTypeface(null, 1);
        TextView s = label(subtitle, 14, Color.rgb(180,220,180));
        box.addView(h);
        box.addView(s);
        return box;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(6,16,6));
        getWindow().setNavigationBarColor(Color.rgb(6,16,6));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(6,16,6));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(12), dp(10), dp(12), dp(10));
        ImageButton menu = new ImageButton(this);
        menu.setImageResource(com.zyphora.app.R.drawable.ic_menu);
        menu.setBackgroundColor(Color.TRANSPARENT);
        menu.setContentDescription("Open menu");
        menu.setPadding(dp(12), dp(12), dp(12), dp(12));
        TextView title = label("Zyphora", 23, Color.rgb(105,255,50));
        title.setTypeface(null, 1);
        header.addView(menu, new LinearLayout.LayoutParams(dp(52), dp(52)));
        header.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(8), dp(16), dp(28));

        ImageView hero = new ImageView(this);
        hero.setImageResource(com.zyphora.app.R.drawable.zyphora_brand);
        hero.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable heroBg = new GradientDrawable();
        heroBg.setCornerRadius(dp(24));
        hero.setBackground(heroBg);
        content.addView(hero, new LinearLayout.LayoutParams(-1, dp(310)));

        TextView welcome = label("Digital community & billboard platform", 18, Color.WHITE);
        welcome.setPadding(dp(4), dp(18), dp(4), dp(8));
        content.addView(welcome);

        content.addView(card("Play", "Tebak Lagu • Tebak Kata"), new LinearLayout.LayoutParams(-1, dp(90)));
        Space gap1 = new Space(this); content.addView(gap1, new LinearLayout.LayoutParams(1, dp(10)));
        content.addView(card("Server", "SimpleSMP Rework • Clan"), new LinearLayout.LayoutParams(-1, dp(90)));
        Space gap2 = new Space(this); content.addView(gap2, new LinearLayout.LayoutParams(1, dp(10)));
        content.addView(card("Promote", "Basic • Standard • Premium • Billboard"), new LinearLayout.LayoutParams(-1, dp(90)));
        Space gap3 = new Space(this); content.addView(gap3, new LinearLayout.LayoutParams(1, dp(10)));
        content.addView(card("Music", "Play music from a URL"), new LinearLayout.LayoutParams(-1, dp(90)));
        Space gap4 = new Space(this); content.addView(gap4, new LinearLayout.LayoutParams(1, dp(10)));
        content.addView(card("Settings", "Indonesia • English • Melayu/Malaysia"), new LinearLayout.LayoutParams(-1, dp(90)));

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        menu.setOnClickListener(v -> {
            // Navigation placeholder for the first build.
        });
    }
}
