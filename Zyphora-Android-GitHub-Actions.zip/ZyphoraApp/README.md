# Zyphora Android Project

Starter Android project for **Zyphora**, using the supplied Zyphora artwork as the app branding.

## Build APK using only a phone

This project includes a GitHub Actions workflow at:

`.github/workflows/build-apk.yml`

GitHub's hosted runner performs the Android build in the cloud, so Android Studio is not required on your phone. GitHub Actions can run workflows on hosted virtual machines and store build outputs as downloadable artifacts.

### Steps

1. Create a GitHub repository from your phone.
2. Upload all files/folders from this project to the repository, including the hidden `.github/workflows/build-apk.yml` file.
3. Open the repository's **Actions** tab.
4. Select **Build Zyphora APK**.
5. Tap **Run workflow** if you want to start it manually.
6. Wait until the workflow finishes successfully.
7. Open the completed workflow run and find **Artifacts**.
8. Download **Zyphora-APK**.
9. Extract the downloaded artifact and install `app-debug.apk` on Android.

The workflow also runs automatically when code is pushed to `main` or `master`.

## App

- App name: Zyphora
- Application ID: com.zyphora.app
- Minimum Android: API 24
- Target Android: API 35
- Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Important

This is currently a starter Android UI project. The full Zyphora business features (Supabase, Google login, campaigns, billing, Billboard, Owner Dashboard, Buyer Dashboard, uploads, etc.) still need to be implemented in the application.
